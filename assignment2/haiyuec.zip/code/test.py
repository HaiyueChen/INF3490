import numpy as np 
matrix = np.array([1, 6, 3])
print(np.argmax(matrix))